/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import javax.swing.JOptionPane;

/**
 *
 * @author Fabricio
 */
public class Sistema {
    private Usuario[] usuarios;
    private Estudiante[] estudiantes;
    private Docente[] docentes;
    private int cantidadUsuarios;
    private int cantidadEstudiantes;
    private int cantidadDocentes;

    public Sistema() {
        usuarios = new Usuario[10000];
        estudiantes = new Estudiante[10000];
        docentes =new Docente[10000];
        cantidadUsuarios = 0;
        this.cantidadEstudiantes = 0;
        this.cantidadDocentes = 0;
    }
    public Usuario iniciarSesion(String nombreUsuario, String contraseña) {
        for (int i = 0; i < cantidadUsuarios; i++) {
            if (usuarios[i].login(nombreUsuario, contraseña)) {
                System.out.println("inicio de sesion exitoso");
                return usuarios[i];
                
            }
        }
        return null;
    }
    public void registrarUsuario(Usuario usuario) {
        for (int i = 0; i < cantidadUsuarios; i++) {
            if (usuarios[i].getNombreUsuario().equals(usuario.getNombreUsuario())) {
                System.out.println("Error: El usuario ya existe.");
                return;
            }
        }
        if (cantidadUsuarios < usuarios.length) {
            usuarios[cantidadUsuarios] = usuario;
            cantidadUsuarios++;
            System.out.println("Usuario registrado: " + usuario.getNombreUsuario());
        } else {
            System.out.println("No se pueden registrar más usuarios. Capacidad máxima alcanzada.");
        }
        
    }
    public void registroEstudiante (Estudiante estudiante){
        for (int i = 0; i < cantidadEstudiantes; i++) {
            if (estudiantes[i].getNombreUsuario().equals(estudiante.getNombreUsuario())) {
                System.out.println("Error: El usuario ya existe.");
                return;
            }
        }
        if (cantidadEstudiantes < estudiantes.length) {
            estudiantes[cantidadEstudiantes] = estudiante;
            cantidadEstudiantes++;
            System.out.println("Usuario registrado: " + estudiante.getNombreUsuario());
        } else {
            System.out.println("No se pueden registrar más usuarios. Capacidad máxima alcanzada.");
        }
    }
    public void registroDocente(Docente docente){
        for (int i = 0; i < cantidadDocentes; i++) {
            if (docentes[i].getNombreUsuario().equals(docente.getNombreUsuario())) {
                System.out.println("Error: El usuario ya existe.");
                return;
            }
        }
        if (cantidadDocentes < docentes.length) {
            docentes[cantidadDocentes] = docente;
            cantidadDocentes++;
            System.out.println("Usuario registrado: " + docente.getNombreUsuario());
        } else {
            System.out.println("No se pueden registrar más usuarios. Capacidad máxima alcanzada.");
        }
    }

    public void eliminarUsuario(String nombreUsuario) {
        for (int i = 0; i < cantidadUsuarios; i++) {
            if (usuarios[i].getNombreUsuario().equals(nombreUsuario)) {
                if(usuarios[i].getRol()==Rol.ESTUDIANTE){eliminarEstudiante(nombreUsuario);}
                if(usuarios[i].getRol()==Rol.DOCENTE){eliminarDocente(nombreUsuario);}
                for (int j = i; j < cantidadUsuarios - 1; j++) {
                    usuarios[j] = usuarios[j + 1];
                }
                usuarios[cantidadUsuarios - 1] = null;
                cantidadUsuarios--;
                JOptionPane.showMessageDialog(null, "Usuario Eliminado!!!");
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Usuario no Encontrado!!!");
    }
    
    public void eliminarEstudiante(String nombreUsuario) {
        for (int i = 0; i < cantidadEstudiantes; i++) {
            if (estudiantes[i].getNombreUsuario().equals(nombreUsuario)) {
                for (int j = i; j < cantidadEstudiantes - 1; j++) {
                    estudiantes[j] = estudiantes[j + 1];
                }
                estudiantes[cantidadEstudiantes - 1] = null;
                cantidadEstudiantes--;
                System.out.println("Estudiante eliminado: " + nombreUsuario);
                return;
            }
        }
        System.out.println("Estudainte no encontrado: " + nombreUsuario);
    }
    
    public void eliminarDocente(String nombreUsuario) {
        for (int i = 0; i < cantidadDocentes; i++) {
            if (docentes[i].getNombreUsuario().equals(nombreUsuario)) {
                for (int j = i; j < cantidadDocentes - 1; j++) {
                    docentes[j] = docentes[j + 1];
                }
                docentes[cantidadDocentes - 1] = null;
                cantidadDocentes--;
                System.out.println("Docentes eliminado: " + nombreUsuario);
                return;
            }
        }
        System.out.println("Docentes no encontrado: " + nombreUsuario);
    }

    public void mostrarUsuarios() {
        System.out.println("Lista de usuarios registrados:");
        for (int i = 0; i < cantidadUsuarios; i++) {
            System.out.println("- " + usuarios[i].getNombreUsuario() + " (" + usuarios[i].getRol() + ")");
        }
    }

    public Usuario[] getUsuarios() {
        return usuarios;
    }

    public int getCantidadUsuarios() {
        return cantidadUsuarios;
    }

    public void setUsuarios(Usuario[] usuarios) {
        this.usuarios = usuarios;
    }

    public void setCantidadUsuarios(int cantidadUsuarios) {
        this.cantidadUsuarios = cantidadUsuarios;
    }

    public Estudiante[] getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(Estudiante[] estudiantes) {
        this.estudiantes = estudiantes;
    }

    public Docente[] getDocentes() {
        return docentes;
    }

    public void setDocentes(Docente[] docentes) {
        this.docentes = docentes;
    }

    public int getCantidadEstudiantes() {
        return cantidadEstudiantes;
    }

    public void setCantidadEstudiantes(int cantidadEstudiantes) {
        this.cantidadEstudiantes = cantidadEstudiantes;
    }

    public int getCantidadDocentes() {
        return cantidadDocentes;
    }

    public void setCantidadDocentes(int cantidadDocentes) {
        this.cantidadDocentes = cantidadDocentes;
    }
    
}
