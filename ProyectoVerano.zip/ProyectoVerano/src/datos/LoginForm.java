/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginForm extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    
    private Sistema sis;
    private Carrera car;
    private Usuario admin;

    // Constructor que recibe los usuarios
    public LoginForm(Usuario admin,Sistema sis,Carrera car) {
        this.admin = admin;
        this.sis = sis;
        this.car = car;
        setTitle("Login de Usuario");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }
    
    public LoginForm(Sistema sis,Carrera car){
        this.sis=sis;
        setTitle("Login de Usuario");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblUsername = new JLabel("Usuario:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(lblUsername, gbc);

        txtUsername = new JTextField(15);
        gbc.gridx = 1;
        panel.add(txtUsername, gbc);

        JLabel lblPassword = new JLabel("Contraseña:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(lblPassword, gbc);

        txtPassword = new JPasswordField(15);
        gbc.gridx = 1;
        panel.add(txtPassword, gbc);

        btnLogin = new JButton("Ingresar");
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(btnLogin, gbc);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleLogin();
            }
        });

        add(panel);
    }

    private void handleLogin() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());
            
        LoginManager loginManager = new LoginManager();

        boolean isValid = loginManager.authenticate(username, password, sis.getUsuarios());

        if (isValid) {
            JOptionPane.showMessageDialog(this, "¡Bienvenido, " + username + "!", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);

            Usuario usuarioLogeado = null;
            for (Usuario usuario : sis.getUsuarios()) {
                if (usuario != null && usuario.getNombreUsuario().equals(username)) {
                    usuarioLogeado = usuario;
                    break;
                }
            }
                
            if (usuarioLogeado != null) {
                if (usuarioLogeado.getRol() == Rol.ADMINISTRADOR) {

                    Admin adminInterface = new Admin(this.sis,usuarioLogeado,this.car);
                    adminInterface.setVisible(true);
                } else if (usuarioLogeado.getRol() == Rol.ESTUDIANTE) {
                    Estudiante estudiante = null;
                    for (Estudiante est : sis.getEstudiantes()) {
                        if (est != null && est.getNombreUsuario().equals(username)) {
                            estudiante = est;
                            break;
                        }
                    }
                    if (estudiante != null) {
                        EstudiantePanel estudiantePanel = new EstudiantePanel(estudiante);
                        estudiantePanel.setVisible(true);  // Mostrar la interfaz de Estudiante
                    } else {
                        JOptionPane.showMessageDialog(this, "Estudiante no encontrado en el sistema", "Error", JOptionPane.ERROR_MESSAGE);
                        this.setVisible(true);
                    }
                } else if (usuarioLogeado.getRol() == Rol.DOCENTE) {
                    Docente docente = null;
                    for (Docente doc : sis.getDocentes()) {
                        if (doc != null && doc.getNombreUsuario().equals(username)) {
                            docente = doc;
                            break;
                        }
                    }
                    if (docente != null) {
                        MenuDocente menuDocente = new MenuDocente(docente,this.sis,this.car);
                        menuDocente.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(this, "Docente no encontrado en el sistema", "Error", JOptionPane.ERROR_MESSAGE);
                        this.setVisible(true);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Usuario no encontrado en el sistema", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales incorrectas", "Error", JOptionPane.ERROR_MESSAGE);
        }
            
    }

    public static void main(String[] args) {
        
        
    }
}
