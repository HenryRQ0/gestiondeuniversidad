/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import javax.swing.JOptionPane;

/**
 *
 * @author Fabricio
 */
public class Carrera {
    private String nombreCarrera;
    private String planEstudios;
    private Asignatura[] asignaturas;
    private int cantidadAsignaturas;

    public Carrera(String nombreCarrera, String planEstudios, int maxAsignaturas) {
        this.nombreCarrera = nombreCarrera;
        this.planEstudios = planEstudios;
        this.asignaturas = new Asignatura[maxAsignaturas];
        this.cantidadAsignaturas = 0;
    }
    public Carrera() {
        this.nombreCarrera = "";
        this.planEstudios = "";
        this.asignaturas = new Asignatura[101];
        this.cantidadAsignaturas = 0;
    }

    public void agregarAsignatura(Asignatura asignatura) {
        if (cantidadAsignaturas < asignaturas.length) {
            asignaturas[cantidadAsignaturas] = asignatura;
            cantidadAsignaturas++;
            System.out.println("añadido");
        } else {
            System.out.println("no añadido");
        }
    }

    public void gestionarInformacion() {
        System.out.println("Información de la carrera: " + nombreCarrera);
        System.out.println("Plan de estudios: " + planEstudios);
        for (int i = 0; i < cantidadAsignaturas; i++) {
            System.out.println("Asignatura " + (i + 1) + ": " + asignaturas[i].getNombreAsignatura());
        }
    }

    public String getNombreCarrera() {
        return nombreCarrera;
    }

    public void setNombreCarrera(String nombreCarrera) {
        this.nombreCarrera = nombreCarrera;
    }

    public String getPlanEstudios() {
        return planEstudios;
    }

    public void setPlanEstudios(String planEstudios) {
        this.planEstudios = planEstudios;
    }

    public Asignatura[] getAsignaturas() {
        return asignaturas;
    }

    public void setAsignaturas(Asignatura[] asignaturas) {
        this.asignaturas = asignaturas;
    }

    public int getCantidadAsignaturas() {
        return cantidadAsignaturas;
    }

    public void setCantidadAsignaturas(int cantidadAsignaturas) {
        this.cantidadAsignaturas = cantidadAsignaturas;
    }
    
}
