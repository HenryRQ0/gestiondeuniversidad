/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

/**
 *
 * @author Fabricio
 */
public class Usuario {
    protected String nombreUsuario;
    protected String contraseña;
    protected Rol rol;

    public Usuario(String nombreUsuario, String contraseña, Rol rol) {
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
        this.rol = rol;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public Rol getRol() {
        return rol;
    }

    public boolean login(String usuario, String contrasena) {
        return this.nombreUsuario.equals(usuario) && this.contraseña.equals(contrasena);
    }

    public void logout() {
        System.out.println("Usuario desconectado: " + nombreUsuario);
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
}
