/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

/**
 *
 * @author Fabricio
 */


public class LoginManager {

    // Método para autenticar al usuario
    public boolean authenticate(String username, String password, Usuario[] usuariosRegistrados) {
        for (Usuario usuario : usuariosRegistrados) {
            if (usuario != null && usuario.nombreUsuario.equals(username) && usuario.contraseña.equals(password)) {
                return true;  // Si encuentra un usuario con las credenciales correctas
            }
        }
        return false;  // Si no encuentra el usuario o las credenciales no coinciden
    }
}
