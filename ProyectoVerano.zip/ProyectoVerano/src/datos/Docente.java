/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

/**
 *
 * @author Fabricio
 */
public class Docente extends Usuario {
    private Asignatura asignatura;
    private Estudiante[] estudiantesInscritos;
    private int cantidadEstudiantes;

    public Docente(String nombreUsuario, String contraseña) {
        super(nombreUsuario, contraseña, Rol.DOCENTE);
        estudiantesInscritos = new Estudiante[100]; // Máximo 10 estudiantes
        cantidadEstudiantes = 0;
    }

    public void asignarAsignatura(Asignatura asignatura) {
        this.asignatura = asignatura;
        System.out.println("Asignatura asignada: " + asignatura.getNombreAsignatura());
    }

    public void inscribirEstudiante(Estudiante estudiante) {
        if (cantidadEstudiantes < estudiantesInscritos.length) {
            estudiantesInscritos[cantidadEstudiantes] = estudiante;
            cantidadEstudiantes++;
            System.out.println("Estudiante inscrito: " + estudiante.getNombreUsuario());
        } else {
            System.out.println("No se pueden inscribir más estudiantes en esta asignatura.");
        }
    }
    public void cambiarNota(String nombreEstudiante, Asignatura asignatura, int nuevaNota) {
    for (int i = 0; i < estudiantesInscritos.length; i++) {
        if (estudiantesInscritos[i] != null && estudiantesInscritos[i].getNombreU().equals(nombreEstudiante)) {
            estudiantesInscritos[i].setCalificaciones(asignatura, nuevaNota);
            System.out.println("Nota cambiada para " + nombreEstudiante + " en " + asignatura.getNombreAsignatura());
            break; // Salimos del bucle cuando encontramos el estudiante
        }
    }
}
    public Asignatura getAsignatura() {
        return asignatura;
    }
    public Estudiante[] getEstudiantesInscritos() {
        return estudiantesInscritos;
    }
    public int getCantidadEstudiantes() {
        return cantidadEstudiantes;
    }
    public String getContraseña() {
        return contraseña;
    }
    public void setAsignatura(Asignatura asignatura) {
        this.asignatura = asignatura;
    }
    public void setEstudiantesInscritos(Estudiante[] estudiantesInscritos) {
        this.estudiantesInscritos = estudiantesInscritos;
    }
    public void setCantidadEstudiantes(int cantidadEstudiantes) {
        this.cantidadEstudiantes = cantidadEstudiantes;
    }
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    public void setRol(Rol rol) {
        this.rol = rol;
    }
}