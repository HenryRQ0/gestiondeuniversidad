
package datos;


import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
public class conexion {
    Connection conexion=null;
    public Connection conexion(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            //conexion = DriverManager.
            conexion=(Connection) java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/proyect1","root",""); 
            System.out.println("conexio exitosa....");
        } catch(Exception e){
            System.out.println("mensaje de error "+e);
            JOptionPane.showMessageDialog(null,"no se pudo conectar");
            
        }
        
        return conexion;
    }
    
    
}
