/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

/**
 *
 * @author Fabricio
 */
public class Asignatura {
    private String nombreAsignatura;
    private String codigo;

    public Asignatura(String nombreAsignatura, String codigo) {
        this.nombreAsignatura = nombreAsignatura;
        this.codigo = codigo;
    }

    public String getNombreAsignatura() {
        return nombreAsignatura;
    }
    public void mostrar(){
        System.out.print("nombre: "+nombreAsignatura+" codigo de asignatura "+codigo);
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
}
