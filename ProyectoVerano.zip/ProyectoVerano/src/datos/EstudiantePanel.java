/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EstudiantePanel extends JFrame {
    private Estudiante estudiante; // Se mantiene la referencia al estudiante
    private JButton btnConsultarMaterias;
    private JButton btnInscribirMateria;
    private JButton btnCerrarSesion;
    private JTextArea textArea; // Para mostrar las materias inscritas
    private JTextField txtMateriaNombre; // Campo de texto para ingresar el nombre de la materia

    public EstudiantePanel(Estudiante estudiante) {
        this.estudiante = estudiante;
        setTitle("Panel de Estudiante");
        setSize(450, 350);  // Se aumenta el tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout()); // Usamos BorderLayout para organizar los componentes

        // Creamos el área de texto para mostrar las materias inscritas
        textArea = new JTextArea(10, 30);
        textArea.setEditable(false); // No queremos que el usuario edite el área
        JScrollPane scrollPane = new JScrollPane(textArea); // Agregamos scroll en caso de que haya muchas materias
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 1, 10, 10)); // Se cambió a 5 filas para encajar el nuevo campo de texto y agregar más espacio entre componentes

        btnConsultarMaterias = new JButton("Consultar Materias Inscritas");
        btnConsultarMaterias.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                consultarMateriasInscritas();
            }
        });
        buttonPanel.add(btnConsultarMaterias);

        // Etiqueta para indicar que el estudiante debe ingresar el nombre de la materia
        JPanel materiaPanel = new JPanel();
        materiaPanel.setLayout(new FlowLayout(FlowLayout.LEFT)); // Usamos FlowLayout para alinear los componentes
        JLabel lblMateria = new JLabel("Ingrese el nombre de la materia:");
        materiaPanel.add(lblMateria);

        // Campo de texto para ingresar el nombre de la materia (ahora más grande)
        txtMateriaNombre = new JTextField(30);  // Aumentamos el número de columnas
        txtMateriaNombre.setPreferredSize(new Dimension(300, 30));  // Ajustamos el tamaño preferido del campo
        materiaPanel.add(txtMateriaNombre);

        // Añadir el panel con la etiqueta y el campo de texto al panel principal
        buttonPanel.add(materiaPanel);

        btnInscribirMateria = new JButton("Inscribir Materia");
        btnInscribirMateria.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el nombre de la materia del campo de texto
                String nombreMateria = txtMateriaNombre.getText().trim();
                if (!nombreMateria.isEmpty()) {
                    // Creamos la asignatura con el nombre ingresado y un código ficticio
                    Asignatura asignatura = new Asignatura(nombreMateria, "CÓDIGO123");
                    estudiante.inscribirAsignatura(asignatura);
                    JOptionPane.showMessageDialog(EstudiantePanel.this, "Materia inscrita: " + asignatura.getNombreAsignatura());
                    txtMateriaNombre.setText("");  // Limpiar el campo de texto después de inscribir la materia
                    consultarMateriasInscritas();  // Actualizar la lista de materias inscritas
                } else {
                    JOptionPane.showMessageDialog(EstudiantePanel.this, "Por favor, ingrese el nombre de la materia.");
                }
            }
        });
        buttonPanel.add(btnInscribirMateria);

        btnCerrarSesion = new JButton("Cerrar Sesión");
        btnCerrarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);  // Aquí solo cerramos la aplicación
            }
        });
        buttonPanel.add(btnCerrarSesion);

        panel.add(buttonPanel, BorderLayout.SOUTH); // Los botones al fondo

        add(panel);
    }

    private void consultarMateriasInscritas() {
        textArea.setText("");  // Limpiamos el área de texto antes de mostrar las materias
        if (estudiante.getCantidadAsignaturas() > 0) {
            for (int i = 0; i < estudiante.getCantidadAsignaturas(); i++) {
                Asignatura asignatura = estudiante.getAsignaturas()[i];
                Calificacion calificacion = estudiante.getCalificaciones()[i];
                if (asignatura != null && calificacion != null) {
                    textArea.append("-Asignatura: " + asignatura.getNombreAsignatura() + " - Nota: " + calificacion.getNota() + "\n");
                }
            }
        } else {
            textArea.append("No hay materias inscritas.\n");
        }
    }
}
