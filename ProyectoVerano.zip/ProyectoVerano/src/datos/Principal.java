
package datos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Principal {
    static conexion a = new conexion();

    
    public static void main(String[] args) {
        //createEstudiante(2,"b",1);
        createCarrera("Informatica");
        
        createDocente("Pedro","pedro123","4"); 
        
        createEstudiante("Juan", "juan123", "123456", 7, 2);
        
        createAsignatura("programacion", "inf-121", 1, 1);
        
        
        
        Sistema sistema = new Sistema();
        AdministradorDelSistema admin = new AdministradorDelSistema("admin", "admin123");
        sistema.registrarUsuario(admin);
        Estudiante est1=new Estudiante("Juan","juan123","123456",7);
        sistema.registrarUsuario(est1);
        admin.añadirEstudiante(est1, sistema);
        Docente doc1=new Docente("Pedro","pedro123");
        
        Estudiante est2=new Estudiante("Marco","mar123","333333",7);
        sistema.registrarUsuario(est2);
        admin.añadirEstudiante(est2, sistema);
        doc1.inscribirEstudiante(est2);
        Estudiante est3=new Estudiante("Jose","jose123","444444",7);
        sistema.registrarUsuario(est3);
        admin.añadirEstudiante(est3, sistema);
        doc1.inscribirEstudiante(est3);
        Estudiante est4=new Estudiante("Miriam","miri123","555555",7);
        sistema.registrarUsuario(est4);
        admin.añadirEstudiante(est4, sistema);
        doc1.inscribirEstudiante(est4);
        
        sistema.registrarUsuario(doc1);
        admin.añadirDocente(doc1, sistema);
        Carrera car=new Carrera("Informatica","Ing Sistemas",100);
        
        Asignatura a1=new Asignatura("Programacion 1","inf-111");
         Asignatura a2=new Asignatura("Programacion 2","inf-121");
        car.agregarAsignatura(a1);
        car.agregarAsignatura(a2);
        
        LoginForm loginForm = new LoginForm(admin,sistema,car);
        loginForm.setVisible(true);
    }
    
     public static void createCarrera(String nombreCarrera) {
        String query = "INSERT INTO Carreras (nombreCarrera) VALUES (?)";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, nombreCarrera);
            stmt.executeUpdate();
            System.out.println("Carrera creada correctamente.");
        } catch (SQLException ex) {
            System.out.println("Error al crear carrera: " + ex.getMessage());
        }
    }
    
   
     
     
     /*
     public static void createEstudiante(int nombreUsuario, String contraseña, int matricula) {
        String query = "INSERT INTO `estudiantes`(`idEstudiante`, `matricula`, `idCarrera`) VALUES (?,?,?)";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, nombreUsuario);
            stmt.setString(2, contraseña);
            stmt.setInt(3, matricula);
           // stmt.setDouble(2, precio);
            stmt.executeUpdate();
            System.out.println("Producto creado correctamente.");
        } catch (SQLException ex) {
            System.out.println(ex);}
    } */
     
    // Leer todos los productos
    public static void createDocente(String NombreDoc, String Contraseña, String asignaturasJson) {
        String query = "INSERT INTO Docentes (NombreDoc, Contraseña, asignaturas) VALUES (?,?,?)";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, NombreDoc);
            stmt.setString(2, Contraseña);
            stmt.setString(3, asignaturasJson);
            stmt.executeUpdate();
            System.out.println("Docente creado correctamente.");
        } catch (SQLException ex) {
            System.out.println("Error al crear docente: " + ex.getMessage());
        }
    }
    
     public static void createEstudiante(String NombreEst, String Contraseña, String matricula, int NroMaterias, int idCarrera) {
        String query = "INSERT INTO Estudiantes (NombreEst, Contraseña, matricula, NroMaterias, idCarrera) VALUES (?,?,?,?, ?)";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1,NombreEst);
            stmt.setString(2, Contraseña);
            stmt.setString(3,matricula);
            stmt.setInt(4, NroMaterias);
            stmt.setInt(5, idCarrera);
            stmt.executeUpdate();
            System.out.println("Estudiante creado correctamente.");
        } catch (SQLException ex) {
            System.out.println("Error al crear estudiante: " + ex.getMessage());
        }
    }

    // Actualizar un producto
    public static void createAsignatura( String nombreAsignatura, String codigo, int idCarrera, int idDocente) {
        String query = "INSERT INTO Asignaturas ( nombreAsignatura, codigo, idCarrera, idDocente) VALUES (?, ?, ?, ?)";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            //stmt.setInt(1, idAsignatura);
            stmt.setString(1, nombreAsignatura);
            stmt.setString(2, codigo);
            stmt.setInt(3, idCarrera);
            stmt.setInt(4, idDocente);
            stmt.executeUpdate();
            System.out.println("Asignatura creada correctamente.");
        } catch (SQLException ex) {
            System.out.println("Error al crear asignatura: " + ex.getMessage());
        }
    }

    // Eliminar un producto
     public static void readCarreras() {
        String query = "SELECT * FROM Carreras";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                System.out.println("ID Carrera: " + rs.getInt("idCarrera"));
                System.out.println("Nombre Carrera: " + rs.getString("nombreCarrera"));
                System.out.println("---------------------------");
            }
        } catch (SQLException ex) {
            System.out.println("Error al leer carreras: " + ex.getMessage());
        }
    }
     
     public static void readEstudiantes() {
        String query = "SELECT * FROM Estudiantes";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                System.out.println("ID Estudiante: " + rs.getInt("idEstudiante"));
                System.out.println("Matrícula: " + rs.getString("matricula"));
                System.out.println("ID Carrera: " + rs.getInt("idCarrera"));
                System.out.println("---------------------------");
            }
        } catch (SQLException ex) {
            System.out.println("Error al leer estudiantes: " + ex.getMessage());
        }
    }
     
     
     public static void readDocentes() {
        String query = "SELECT * FROM Docentes";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                System.out.println("ID Docente: " + rs.getInt("idDocente"));
                System.out.println("Asignaturas: " + rs.getString("asignaturas"));
                System.out.println("---------------------------");
            }
        } catch (SQLException ex) {
            System.out.println("Error al leer docentes: " + ex.getMessage());
        }
    }
     
     
     public static void readAsignaturas() {
        String query = "SELECT * FROM Asignaturas";
        try (Connection conn = a.conexion();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                System.out.println("ID Asignatura: " + rs.getInt("idAsignatura"));
                System.out.println("Nombre Asignatura: " + rs.getString("nombreAsignatura"));
                System.out.println("Código: " + rs.getString("codigo"));
                System.out.println("ID Carrera: " + rs.getInt("idCarrera"));
                System.out.println("ID Docente: " + rs.getInt("idDocente"));
                System.out.println("---------------------------");
            }
        } catch (SQLException ex) {
            System.out.println("Error al leer asignaturas: " + ex.getMessage());
        }
    }
}
