/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

/**
 *
 * @author Fabricio
 */
public class Estudiante extends Usuario {
    private String matricula;
    private Asignatura[] asignaturas;
    private Calificacion[] calificaciones;
    private int cantidadAsignaturas;

    public Estudiante(String nombreUsuario, String contraseña, String matricula, int maxAsignaturas) {
        super(nombreUsuario, contraseña, Rol.ESTUDIANTE);
        this.matricula = matricula;
        this.asignaturas = new Asignatura[maxAsignaturas];
        this.cantidadAsignaturas = 0;
        this.calificaciones = new Calificacion[maxAsignaturas];
    }
public void inscribirAsignatura(Asignatura asignatura) {
    if (cantidadAsignaturas < asignaturas.length) {
        asignaturas[cantidadAsignaturas] = asignatura;
        calificaciones[cantidadAsignaturas] = new Calificacion(asignatura); // Inicializa la calificación
        cantidadAsignaturas++;
        System.out.println("Asignatura inscrita: " + asignatura.getNombreAsignatura());
    } else {
        System.out.println("No se pueden inscribir más asignaturas.");
    }
}
    public void consultarMateriasInscritas() {
    System.out.println("Materias inscritas para el estudiante: " + nombreUsuario);
    
    // Verifica si hay asignaturas
    if (cantidadAsignaturas > 0) {
        for (int i = 0; i < cantidadAsignaturas; i++) {
            // Asegúrate de que las asignaturas y calificaciones no sean nulas
            if (asignaturas[i] != null && calificaciones[i] != null) {
                System.out.println("-Asignatura " + asignaturas[i].getNombreAsignatura() +
                    " nota " + calificaciones[i].getNota());
            }
        }
    } else {
        System.out.println("No hay asignaturas inscritas.");
    }
}

    public String getMatricula() {
        return matricula;
    }
    public Asignatura[] getAsignaturas() {
        return asignaturas;
    }
    public Calificacion[] getCalificaciones() {
        return calificaciones;
    }
    public int getCantidadAsignaturas() {
        return cantidadAsignaturas;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    public void setAsignaturas(Asignatura[] asignaturas) {
        this.asignaturas = asignaturas;
    }
    public void setCalificaciones(Asignatura as, int califi) {
        for (int i = 0; i < this.getCantidadAsignaturas(); i++) {
            if (this.calificaciones[i] != null && calificaciones[i].getAsig().equals(as)) {
                calificaciones[i].setNota(califi);
                break;  // Salimos del bucle una vez que encontramos la asignatura
            }
        }
    }   
    public void setCantidadAsignaturas(int cantidadAsignaturas) {
        this.cantidadAsignaturas = cantidadAsignaturas;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }
    public String getNombreU() {
        return this.nombreUsuario;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }
    
}
