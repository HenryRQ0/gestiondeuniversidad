/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

/**
 *
 * @author Fabricio
 */
public class Calificacion {
    private Asignatura asig;
    private int nota;

    public Calificacion(Asignatura asig) {
        this.asig = asig;
        this.nota = 0; 
    }
    public Asignatura getAsig() {
        return asig;
    }
    public int getNota() {
        return nota;
    }
    public void setAsig(Asignatura asig) {
        this.asig = asig;
    }
    public void setNota(int nota) {
        this.nota = nota;
    }
    public void mostrar(){
        System.out.print("asignatura: "+asig.getNombreAsignatura()+" nota "+nota);
    }
}
