/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package datos;

/**
 *
 * @author Fabricio
 */
public class ProyectoInterf {

    public static void main(String[] args) {
        // Crear el sistema
        Sistema sistema = new Sistema();

        // Crear usuarios
        AdministradorDelSistema admin = new AdministradorDelSistema("admin", "admin123");
        Docente docente = new Docente("profesor1", "prof123");
        Estudiante estudiante1 = new Estudiante("estudiante1", "est123", "2021001", 5);
        Estudiante estudiante2 = new Estudiante("estudiante2", "est456", "2021002", 5);

        // Registrar usuarios en el sistema
        sistema.registrarUsuario(admin);
        sistema.registrarUsuario(docente);
        sistema.registrarUsuario(estudiante1);
        sistema.registrarUsuario(estudiante2);

        // Mostrar usuarios registrados
        admin.gestionarUsuarios(sistema);

        // Iniciar sesión
        Usuario usuario = sistema.iniciarSesion("estudiante1", "est123");
        if (usuario != null) {
            System.out.println("Inicio de sesión exitoso para: " + usuario.getNombreUsuario());
        } else {
            System.out.println("Error en el inicio de sesión.");
        }

        // Inscribir asignaturas para estudiantes
        Asignatura matematicas = new Asignatura("Matemáticas", "MAT101");
        Asignatura fisica = new Asignatura("Física", "FIS101");

        estudiante1.inscribirAsignatura(matematicas);
        estudiante1.inscribirAsignatura(fisica);
        estudiante2.inscribirAsignatura(matematicas);

        // Consultar materias inscritas
        estudiante1.consultarMateriasInscritas();
        estudiante2.consultarMateriasInscritas();

        // Asignar asignatura a docente
        docente.asignarAsignatura(matematicas);

        // Inscribir estudiantes en la asignatura del docente
        docente.inscribirEstudiante(estudiante1);
        docente.inscribirEstudiante(estudiante2);

        // Cambiar nota de un estudiante
        docente.cambiarNota("estudiante1", matematicas, 95);

        // Consultar materias inscritas para verificar el cambio de nota
        estudiante1.consultarMateriasInscritas();

        // Eliminar un usuario
        admin.eliminarUsuario(sistema, "estudiante2");

        // Mostrar usuarios registrados después de la eliminación
        admin.gestionarUsuarios(sistema);
    
    }
}
