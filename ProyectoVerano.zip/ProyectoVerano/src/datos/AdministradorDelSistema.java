/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

/**
 *
 * @author Fabricio
 */
public class AdministradorDelSistema extends Usuario {

    public AdministradorDelSistema(String nombreUsuario, String contraseña) {
        super(nombreUsuario, contraseña, Rol.ADMINISTRADOR);
    }
    
    public void gestionarUsuarios(Sistema sistema) {
        System.out.println("Lista completa de usuarios registrados:");
        sistema.mostrarUsuarios();
    }
    
    public void eliminarUsuario(Sistema sistema,String nombre){
        sistema.eliminarUsuario(nombre);
    }
    public void cambiaUsuario(Usuario ux){
        
    }
    
    public void añadirEstudiante(Estudiante estudiante,Sistema sistema){
        sistema.registroEstudiante(estudiante);
    }
    public void añadirDocente(Docente docente,Sistema sistema){
        sistema.registroDocente(docente);
    }
}

